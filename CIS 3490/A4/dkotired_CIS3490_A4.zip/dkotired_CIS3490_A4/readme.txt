Name: Dinesh Sainath Koti Reddy
ID # 1025287
CIS 3490 Assignment 4


To compile the programs use 'make P1' , 'make p2'
To execute the programs use ' ./P1 '  , ' ./P2 '
